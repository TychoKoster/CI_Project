


class ImageConverter(object):

    def __init__(self):
        pass
    # end __init__

# end ImageConverter